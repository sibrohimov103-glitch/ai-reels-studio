// Tests everything except the live Claude call (needs a real API key + network).
process.env.DATA_DIR = '/tmp/reels-test'; process.env.PORT = '3911';
import fs from 'node:fs';
fs.rmSync('/tmp/reels-test', { recursive: true, force: true });
const { run, probe, prep, renderVariant, qc, server, db, D } = await import('./server.js');
const ok = (n, c, x = '') => console.log(c ? 'PASS' : 'FAIL', n, x);
const src = '/tmp/src.mp4';
await run('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc2=s=1280x720:r=30:d=9', '-f', 'lavfi', '-i', 'sine=f=300:d=9', '-vf', 'crop=1100:640:x=90+40*sin(t*9):y=40+20*cos(t*7)', '-shortest', '-pix_fmt', 'yuv420p', src]);
const meta = await probe(src); ok('probe', meta.dur > 8, JSON.stringify(meta));
const v = { id: 'tv1', file: src, meta }; await prep(v);
ok('stabilize', v.meta.hints.stabilized, v.meta.hints.stabilize_error || ''); ok('blur+freeze detection ran', Array.isArray(v.meta.hints.blurry) && Array.isArray(v.meta.hints.frozen), JSON.stringify({ b: v.meta.hints.blurry.length, f: v.meta.hints.frozen }));
ok('frames', v.frames.length > 0, v.frames.length);
const mk = (n, d) => ({ name: n, hook: 'Test hook', cta: 'Buyurtma uchun DM', music_mood: 'calm', clips: [{ video: 0, start: 0, end: 3 }, { video: 0, start: 4, end: 4 + d }], captions: [{ text: "Bu oddiy ko'rinadi lekin", start: 0.2, end: 2.5 }, { text: 'Narx uchun DM', start: 3, end: 5 }], sfx: [{ t: 0, type: 'pop' }, { t: 3, type: 'whoosh' }, { t: 5.5, type: 'impact' }] });
for (const [i, n] of ['Professional', 'High Retention', 'Direct Selling'].entries()) {
  const r = await renderVariant('t', [v], mk(n, 2.5 + i), 'v' + i), q = await qc(r.file, mk(n, 3));
  ok('render ' + n, q.checks.every((c) => c.ok), `${q.dur.toFixed(1)}s sfx=${r.sfx} ${q.checks.filter((c) => !c.ok).map((c) => c.name)}`);
}
await new Promise((r) => server.listen(3911, r));
const B = 'http://localhost:3911', j = (p, o) => fetch(B + p, o).then(async (r) => [r.status, await r.json().catch(() => ({}))]);
ok('status api', (await j('/api/status'))[0] === 200);
let [s, o] = await j('/api/jobs', { method: 'POST', body: '{}' }); ok('refuses job without API key', s === 400, o.error);
await j('/api/settings', { method: 'POST', body: JSON.stringify({ key: 'bad' }) }); [s] = await j('/api/settings', { method: 'POST', body: JSON.stringify({ key: 'bad' }) }); ok('rejects malformed key', s === 400);
await j('/api/settings', { method: 'POST', body: JSON.stringify({ key: 'sk-ant-test123' }) });
[s, o] = await j('/api/jobs', { method: 'POST', body: JSON.stringify({ name: 'Cup' }) }); ok('create job', s === 200);
[s, o.e] = await j(`/api/jobs/${o.id}/upload?name=x.txt`, { method: 'PUT', body: 'hi' }); ok('rejects bad extension', s === 400);
[s] = await j(`/api/jobs/${o.id}/upload?name=x.mp4`, { method: 'PUT', body: 'not a video' }); ok('rejects fake video', s === 400);
[s] = await j(`/api/jobs/${o.id}/upload?name=a.mp4`, { method: 'PUT', body: fs.readFileSync(src) }); ok('upload real video', s === 200);
await j(`/api/jobs/${o.id}/start`, { method: 'POST' }); let t;
for (let i = 0; i < 90; i++) { await new Promise((r) => setTimeout(r, 1000)); t = (await j(`/api/jobs/${o.id}`))[1]; if (['done', 'failed'].includes(t.status)) break; }
ok('queue ran job; invalid key surfaces readable error + failed state', t.status === 'failed' && /AI service error|Network|fetch/i.test(t.error), t.error);
const f = fs.readdirSync(D + '/out').find((x) => x.endsWith('.mp4')); const rr = await fetch(`${B}/files/${f}`, { headers: { range: 'bytes=0-99' } }); ok('range video serving', rr.status === 206);
await j('/api/settings', { method: 'POST', body: JSON.stringify({ password: 'secret1' }) }); [s] = await j('/api/jobs/x'); ok('password protects API', s === 401);
process.exit(0);

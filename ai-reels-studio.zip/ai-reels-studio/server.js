import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const E = process.env;
export const D = path.resolve(E.DATA_DIR || 'data');
const MAXMB = +E.MAX_UPLOAD_MB || 500;
for (const s of ['up', 'out', 'tmp', 'sfx', 'music']) fs.mkdirSync(`${D}/${s}`, { recursive: true });
export const db = new DatabaseSync(`${D}/app.db`);
db.exec(`create table if not exists settings(k text primary key,v text);
create table if not exists jobs(id text primary key,status text,phase text,error text,info text,plan text,cmd text,created integer);
create table if not exists videos(id text primary key,job text,file text,use text,meta text);
create table if not exists renders(id text primary key,job text,variant text,file text,qc text,status text,error text,ver integer);`);
const S = (k) => db.prepare('select v from settings where k=?').get(k)?.v;
const setS = (k, v) => db.prepare('insert or replace into settings values(?,?)').run(k, v);
const key = () => S('key') || E.ANTHROPIC_API_KEY;
const sha = (x) => crypto.createHash('sha256').update('reels' + x).digest('hex');
const pwHash = () => S('pw') || (E.APP_PASSWORD ? sha(E.APP_PASSWORD) : null);

export const run = (c, a) => new Promise((res, rej) => {
  const p = spawn(c, a); let so = '', se = '';
  p.stdout.on('data', (d) => (so += d)); p.stderr.on('data', (d) => (se += d));
  p.on('error', rej); p.on('close', (x) => (x ? rej(new Error(`${c} failed: ${se.slice(-300)}`)) : res({ so, se })));
});
const ff = (a) => run('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', ...a]);
const retry = async (f, n = 3) => { let e; for (let i = 0; i < n; i++) { try { return await f(i); } catch (x) { e = x; await new Promise((r) => setTimeout(r, 1500 * (i + 1))); } } throw e; };

export async function probe(f) {
  const { so } = await run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration:stream=codec_type,width,height', '-of', 'json', f]);
  const p = JSON.parse(so), v = p.streams.find((s) => s.codec_type === 'video');
  if (!v) throw new Error('no video stream');
  return { dur: +p.format.duration, w: v.width, h: v.height, audio: p.streams.some((s) => s.codec_type === 'audio'), hints: {} };
}

// ---------- footage preparation: stabilize, detect blur + dead (frozen) time, sample frames
export async function prep(v) {
  const base = `${D}/tmp/${v.id}`, m = v.meta; v.use = v.file; m.hints = {};
  if (m.dur <= 180) {
    try {
      await ff(['-i', v.file, '-vf', `vidstabdetect=shakiness=5:result=${base}.trf`, '-an', '-f', 'null', '-']);
      await ff(['-i', v.file, '-vf', `vidstabtransform=input=${base}.trf:smoothing=15:zoom=2,unsharp=3:3:0.4`, '-c:v', 'libx264', '-crf', '18', '-preset', 'veryfast', '-c:a', 'copy', `${base}-s.mp4`]);
      v.use = `${base}-s.mp4`; m.hints.stabilized = true;
    } catch (e) { m.hints.stabilize_error = e.message.slice(0, 120); }
  }
  const b = await run('ffmpeg', ['-hide_banner', '-i', v.use, '-vf', 'fps=5,scale=360:-2,blurdetect=block_pct=80,metadata=print:file=-', '-an', '-f', 'null', '-']);
  const win = {}; let t = 0;
  for (const l of b.so.split('\n')) {
    let x = l.match(/pts_time:([\d.]+)/); if (x) t = +x[1];
    x = l.match(/lavfi\.blur=([\d.]+)/); if (x) (win[Math.floor(t)] ||= []).push(+x[1]);
  }
  const avg = Object.entries(win).map(([s, a]) => [+s, a.reduce((p, c) => p + c, 0) / a.length]);
  const med = avg.map((a) => a[1]).sort((p, c) => p - c)[Math.floor(avg.length / 2)] || 0;
  m.hints.blurry = avg.filter((a) => med > 0 && a[1] > med * 1.6).map((a) => [a[0], a[0] + 1]);
  const fz = await run('ffmpeg', ['-hide_banner', '-i', v.use, '-vf', 'freezedetect=n=0.003:d=1', '-an', '-f', 'null', '-']);
  const st = [...fz.se.matchAll(/freeze_start: ([\d.]+)/g)].map((x) => +x[1]), en = [...fz.se.matchAll(/freeze_end: ([\d.]+)/g)].map((x) => +x[1]);
  m.hints.frozen = st.map((s, i) => [s, en[i] ?? m.dur]);
  const dir = `${base}-fr`; await fsp.mkdir(dir, { recursive: true });
  const step = Math.max(1.5, m.dur / 8);
  await ff(['-i', v.use, '-vf', `fps=1/${step},scale=448:-2`, '-frames:v', '8', '-q:v', '5', `${dir}/%02d.jpg`]);
  v.frames = [];
  for (const [k, n] of (await fsp.readdir(dir)).sort().entries())
    v.frames.push({ t: +(k * step).toFixed(1), b64: (await fsp.readFile(`${dir}/${n}`)).toString('base64') });
}
const overlap = (r, s, e) => r.reduce((a, [x, y]) => a + Math.max(0, Math.min(e, y) - Math.max(s, x)), 0) / (e - s);

// ---------- AI analysis + 3 edit plans (real Claude vision call)
const SCHEMA = `Return ONLY JSON: {"strategy":"","strategy_reason":"","product_guess":"","shots":[{"video":0,"start":0,"end":3,"rank":"BEST|GOOD|USEFUL|WEAK|REMOVE","reason":""}],"hooks":["5 hooks"],"instagram_caption":"","hashtags":[],"cover_text":"","cover_time":0,"versions":[{"name":"Professional|High Retention|Direct Selling","hook":"","clips":[{"video":0,"start":0,"end":2.5,"reason":""}],"captions":[{"text":"","start":0,"end":2}],"cta":"","sfx":[{"t":0.0,"type":"whoosh|pop|click|impact"}],"music_mood":"calm|upbeat|premium|energetic","music_volume":0.12,"color":{"contrast":1.05,"saturation":1.08,"brightness":0.0}}]}`;
async function analyze(info, vids, prev, cmd) {
  if (!key()) throw new Error('No Anthropic API key. Open Settings and paste your key.');
  const content = [];
  vids.forEach((v, i) => {
    const h = v.meta.hints;
    content.push({ type: 'text', text: `VIDEO ${i}: ${v.meta.dur.toFixed(1)}s. Measured: blurry seconds ${JSON.stringify(h.blurry)}, frozen/dead ranges ${JSON.stringify(h.frozen)}, stabilized=${!!h.stabilized}. Frames:` });
    for (const f of v.frames) { content.push({ type: 'text', text: `t=${f.t}s` }); content.push({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: f.b64 } }); }
  });
  content.push({ type: 'text', text: `You are a professional Instagram Reels editor. Product info (may be empty; NEVER invent facts, prices or claims): ${JSON.stringify(info)}.
Rank segments, avoid measured blurry/frozen ranges. Choose a strategy. Write 5 hooks in Uzbek (Latin). Produce THREE versions: Professional (clean, premium, slower), High Retention (fast cuts, strong hook, pattern interrupts, more sfx), Direct Selling (product, benefit, price only if given, strong CTA). Each: clips in play order (0.8-4s each, total 12-30s, strongest shot first, hook matches the first scene), captions max 5 words on the final timeline, CTA in Uzbek, max 6 sfx (times on final timeline, use whoosh on cuts sparingly), music mood.
${prev ? `Current plan: ${JSON.stringify(prev)}\nUser edit command: "${cmd}". Apply it to all three versions.` : ''}
${SCHEMA}` });
  const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'x-api-key': key(), 'anthropic-version': '2023-06-01', 'content-type': 'application/json' }, body: JSON.stringify({ model: S('model') || E.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 6000, messages: [{ role: 'user', content }] }) });
  if (!r.ok) throw new Error(`AI service error ${r.status}${r.status === 401 ? ' (API key rejected)' : ''}`);
  const txt = (await r.json()).content.map((c) => c.text || '').join('');
  const plan = JSON.parse(txt.slice(txt.indexOf('{'), txt.lastIndexOf('}') + 1));
  for (const ver of plan.versions || []) {
    const all = (ver.clips || []).map((c) => { const v = vids[c.video]; if (!v) return null; const s = Math.max(0, +c.start || 0), e = Math.min(v.meta.dur, +c.end || 0); return e - s >= 0.6 ? { ...c, start: s, end: e } : null; }).filter(Boolean);
    const good = all.filter((c) => overlap(vids[c.video].meta.hints.blurry || [], c.start, c.end) < 0.5 && overlap(vids[c.video].meta.hints.frozen || [], c.start, c.end) < 0.6);
    ver.clips = good.length ? good : all;
    ver.sfx = (ver.sfx || []).filter((s) => SFX[s.type] && s.t >= 0).slice(0, 6);
  }
  plan.versions = (plan.versions || []).filter((v) => v.clips.length);
  if (!plan.versions.length) throw new Error('The AI could not find usable shots in this footage.');
  return plan;
}

// ---------- sound effects (synthesized with FFmpeg) and rendering
const SFX = {
  whoosh: ['anoisesrc=d=0.5:c=pink:a=0.6', 'highpass=f=400,lowpass=f=4500,afade=t=in:d=0.2,afade=t=out:st=0.25:d=0.25'],
  pop: ['sine=f=700:d=0.12', 'afade=t=out:d=0.12'],
  click: ['sine=f=2200:d=0.04', 'afade=t=out:d=0.04'],
  impact: ['sine=f=55:d=0.5', 'afade=t=out:st=0.05:d=0.45,volume=2'],
};
async function sfxFile(t) {
  const f = `${D}/sfx/${t}.wav`;
  if (!fs.existsSync(f)) await ff(['-f', 'lavfi', '-i', SFX[t][0], '-af', SFX[t][1], '-ar', '44100', '-ac', '2', f]);
  return f;
}
const ts = (t) => `${Math.floor(t / 3600)}:${String(Math.floor((t % 3600) / 60)).padStart(2, '0')}:${(t % 60).toFixed(2).padStart(5, '0')}`;
const clean = (s) => String(s).replace(/[{}\\\n]/g, ' ');
function ass(caps, total) {
  let ev = '';
  for (const c of caps) {
    const w = clean(c.text).split(/\s+/).filter(Boolean); if (!w.length) continue;
    const st = c.start, en = Math.min(c.end, total), d = (en - st) / w.length;
    w.forEach((_, i) => {
      const txt = w.map((x, j) => (j === i && !c.cta ? `{\\c&H00D7FF&}${x}{\\c&HFFFFFF&}` : x)).join(' ');
      ev += `Dialogue: 0,${ts(st + i * d)},${ts(st + (i + 1) * d)},${c.cta ? 'Cta' : 'Cap'},,0,0,0,,${txt}\n`;
    });
  }
  return `[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nWrapStyle: 0\n[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\nStyle: Cap,DejaVu Sans,72,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,6,0,2,90,90,620,1\nStyle: Cta,DejaVu Sans,58,&H00FFFFFF,&H00FFFFFF,&H00E8731A,&H00E8731A,-1,0,0,0,100,100,0,0,3,18,0,2,90,90,620,1\n[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n${ev}`;
}
async function music(mood) {
  for (const dir of [`${D}/music`, E.MUSIC_DIR].filter(Boolean)) {
    try { const f = (await fsp.readdir(dir)).filter((n) => /\.(mp3|m4a|wav)$/i.test(n)); const m = f.find((n) => n.toLowerCase().includes((mood || '').toLowerCase())) || f[0]; if (m) return path.join(dir, m); } catch {}
  }
  return null;
}
export async function renderVariant(jobId, vids, ver, tag, maxTotal = 60) {
  let total = 0; const clips = [];
  for (const c of ver.clips) { if (total >= maxTotal) break; const d = Math.min(c.end - c.start, maxTotal - total); clips.push({ ...c, end: c.start + d }); total += d; }
  const col = ver.color || {}, inputs = vids.flatMap((v) => ['-i', v.use]); let fc = '';
  clips.forEach((c, i) => {
    const v = vids[c.video], d = c.end - c.start, f = Math.max(0, d - 0.12);
    fc += `[${c.video}:v]trim=${c.start}:${c.end},setpts=PTS-STARTPTS,scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,eq=contrast=${col.contrast || 1.05}:saturation=${col.saturation || 1.08}:brightness=${col.brightness || 0},unsharp=5:5:0.6,hqdn3d=2:1:3:3,fps=30,setsar=1,fade=t=in:d=0.12,fade=t=out:st=${f}:d=0.12[v${i}];`;
    fc += v.meta.audio ? `[${c.video}:a]atrim=${c.start}:${c.end},asetpts=PTS-STARTPTS,aresample=44100,aformat=channel_layouts=stereo[a${i}];` : `anullsrc=r=44100:cl=stereo,atrim=duration=${d}[a${i}];`;
  });
  fc += clips.map((_, i) => `[v${i}][a${i}]`).join('') + `concat=n=${clips.length}:v=1:a=1[v][a0];[a0]loudnorm=I=-16:TP=-1.5[a]`;
  const caps = [...(ver.captions || []).filter((c) => c.start < total), { text: ver.cta, start: Math.max(0, total - 2.5), end: total, cta: 1 }].filter((c) => c.text);
  const af = `${D}/tmp/${jobId}-${tag}.ass`; await fsp.writeFile(af, ass(caps, total));
  fc += `;[v]subtitles=${af}:fontsdir=/usr/share/fonts[vo]`;
  const out = `${D}/out/${jobId}-${tag}-${Date.now()}.mp4`, raw = out + '.tmp.mp4';
  await ff([...inputs, '-filter_complex', fc, '-map', '[vo]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'medium', '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', raw]);
  const sfx = (ver.sfx || []).filter((s) => s.t < total), mu = await music(ver.music_mood), ins = ['-i', raw];
  let mf = '', labels = '[0:a]', n = 1;
  for (const s of sfx) { ins.push('-i', await sfxFile(s.type)); mf += `[${n}:a]adelay=${Math.round(s.t * 1000)}|${Math.round(s.t * 1000)},volume=0.55[s${n}];`; labels += `[s${n}]`; n++; }
  if (mu) { ins.push('-stream_loop', '-1', '-i', mu); mf += `[${n}:a]volume=${ver.music_volume ?? 0.12},afade=t=out:st=${Math.max(0, total - 1)}:d=1[m];`; labels += '[m]'; n++; }
  if (n > 1) { await ff([...ins, '-filter_complex', `${mf}${labels}amix=inputs=${n}:duration=first:dropout_transition=0,volume=${n}[a]`, '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', out]); await fsp.unlink(raw); } else await fsp.rename(raw, out);
  return { file: out, total, sfx: sfx.length, music: !!mu };
}
export async function qc(file, ver) {
  const p = await probe(file);
  return { dur: p.dur, checks: [
    { name: 'Vertical 9:16, 1080x1920', ok: p.w === 1080 && p.h === 1920 },
    { name: 'Duration 5-60 seconds', ok: p.dur >= 5 && p.dur <= 61 },
    { name: 'Audio track present', ok: p.audio },
    { name: 'CTA included', ok: !!ver.cta },
    { name: 'Hook written', ok: !!ver.hook },
  ] };
}

// ---------- job queue (SQLite-backed, one job at a time, survives restarts)
const phase = (id, p) => db.prepare('update jobs set phase=? where id=?').run(p, id);
async function runJob(id) {
  const J = db.prepare('select * from jobs where id=?').get(id), info = JSON.parse(J.info);
  const vids = db.prepare('select * from videos where job=?').all(id).map((r) => ({ ...r, meta: JSON.parse(r.meta) }));
  const fr = `${D}/tmp/${id}-frames.json`; let cache = fs.existsSync(fr) ? JSON.parse(fs.readFileSync(fr)) : null;
  for (const v of vids) {
    if (cache?.[v.id]) { v.frames = cache[v.id]; continue; }
    phase(id, 'Stabilizing and inspecting footage...');
    await retry(() => prep(v), 2);
    db.prepare('update videos set use=?,meta=? where id=?').run(v.use, JSON.stringify(v.meta), v.id);
  }
  fs.writeFileSync(fr, JSON.stringify(Object.fromEntries(vids.map((v) => [v.id, v.frames]))));
  phase(id, 'AI is choosing shots, hook and three edit plans...');
  const prev = J.plan ? JSON.parse(J.plan) : null;
  const plan = await retry(() => analyze(info, vids, J.cmd ? prev : null, J.cmd), 3);
  db.prepare('update jobs set plan=?,cmd=null where id=?').run(JSON.stringify(plan), id);
  db.prepare('delete from renders where job=?').run(id);
  let ok = 0;
  for (const [i, ver] of plan.versions.entries()) {
    const rid = crypto.randomUUID();
    db.prepare('insert into renders values(?,?,?,?,?,?,?,?)').run(rid, id, ver.name, null, null, 'rendering', null, i);
    phase(id, `Rendering version ${i + 1} of ${plan.versions.length}: ${ver.name}...`);
    try {
      let r = await retry(() => renderVariant(id, vids, ver, 'v' + i), 2), q = await qc(r.file, ver);
      if (q.checks.some((c) => !c.ok && /Duration|9:16/.test(c.name))) { r = await renderVariant(id, vids, ver, 'v' + i, 30); q = await qc(r.file, ver); }
      const cover = r.file.replace('.mp4', '.jpg');
      await ff(['-ss', String(Math.min(plan.cover_time || 1, q.dur - 0.1)), '-i', r.file, '-frames:v', '1', cover]);
      db.prepare('update renders set file=?,qc=?,status=? where id=?').run(path.basename(r.file), JSON.stringify({ ...q, sfx: r.sfx, music: r.music }), 'done', rid); ok++;
    } catch (e) { db.prepare('update renders set status=?,error=? where id=?').run('failed', e.message.slice(0, 300), rid); }
  }
  if (!ok) throw new Error('Rendering failed for all versions.');
}
let busy = false;
async function pump() {
  if (busy) return; const j = db.prepare("select id from jobs where status='queued' order by created limit 1").get(); if (!j) return;
  busy = true; db.prepare("update jobs set status='running',error=null where id=?").run(j.id);
  try { await runJob(j.id); db.prepare("update jobs set status='done',phase='Ready!' where id=?").run(j.id); }
  catch (e) { console.error(e); db.prepare("update jobs set status='failed',error=? where id=?").run(e.message.slice(0, 300), j.id); }
  busy = false; pump();
}

// ---------- HTTP
const json = (res, c, o, h = {}) => { res.writeHead(c, { 'content-type': 'application/json', ...h }); res.end(JSON.stringify(o)); };
const body = (req) => new Promise((r) => { let s = ''; req.on('data', (d) => { s += d; if (s.length > 1e6) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(s || '{}')); } catch { r({}); } }); });
const cookie = (req) => /(?:^|; )t=([\w]+)/.exec(req.headers.cookie || '')?.[1];
function serve(req, res, file, dl) {
  fs.stat(file, (e, st) => {
    if (e) return json(res, 404, { error: 'Not found' });
    let s = 0, en = st.size - 1; const r = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
    if (r) { s = r[1] ? +r[1] : st.size - +r[2]; en = r[1] && r[2] ? +r[2] : st.size - 1; }
    const h = { 'content-type': file.endsWith('.mp4') ? 'video/mp4' : file.endsWith('.jpg') ? 'image/jpeg' : 'text/html; charset=utf-8', 'accept-ranges': 'bytes', 'content-length': en - s + 1 };
    if (r) h['content-range'] = `bytes ${s}-${en}/${st.size}`; if (dl) h['content-disposition'] = 'attachment; filename="reel.mp4"';
    res.writeHead(r ? 206 : 200, h); fs.createReadStream(file, { start: s, end: en }).pipe(res);
  });
}
function view(id) {
  const j = db.prepare('select * from jobs where id=?').get(id); if (!j) return null;
  return { id, status: j.status, phase: j.phase, error: j.error, plan: j.plan ? JSON.parse(j.plan) : null,
    renders: db.prepare('select variant,file,qc,status,error from renders where job=? order by ver').all(id).map((r) => ({ ...r, qc: r.qc && JSON.parse(r.qc) })) };
}
const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x'), p = u.pathname, m = req.method;
    if (m === 'GET' && (p === '/' || p === '/index.html')) return serve(req, res, path.resolve('public/index.html'));
    let x;
    if (m === 'GET' && (x = p.match(/^\/files\/([\w-]+\.(mp4|jpg))$/))) return serve(req, res, `${D}/out/${x[1]}`, u.searchParams.has('dl'));
    if (m === 'GET' && p === '/api/status') return json(res, 200, { needsLogin: !!pwHash(), hasKey: !!key() });
    if (m === 'POST' && p === '/api/login') { const b = await body(req); return pwHash() && sha(b.password || '') === pwHash() ? json(res, 200, { ok: 1 }, { 'set-cookie': `t=${pwHash()}; HttpOnly; Path=/; SameSite=Strict; Max-Age=2592000` }) : json(res, 401, { error: 'Wrong password.' }); }
    if (pwHash() && cookie(req) !== pwHash()) return json(res, 401, { error: 'Please log in.' });
    if (p === '/api/settings') {
      if (m === 'POST') {
        const b = await body(req), h = {};
        if (b.key) { if (!/^sk-ant-/.test(b.key)) return json(res, 400, { error: 'That does not look like an Anthropic key (starts with sk-ant-).' }); setS('key', b.key.trim()); }
        if (b.password) { if (b.password.length < 6) return json(res, 400, { error: 'Password must be at least 6 characters.' }); setS('pw', sha(b.password)); h['set-cookie'] = `t=${sha(b.password)}; HttpOnly; Path=/; SameSite=Strict; Max-Age=2592000`; }
        if (b.model) setS('model', String(b.model).slice(0, 60));
        return json(res, 200, { ok: 1 }, h);
      }
      return json(res, 200, { hasKey: !!key(), hasPassword: !!pwHash(), model: S('model') || E.ANTHROPIC_MODEL || 'claude-sonnet-5-5', music: fs.readdirSync(`${D}/music`) });
    }
    if (m === 'PUT' && p === '/api/music') {
      const n = path.basename(u.searchParams.get('name') || '').replace(/[^\w.-]/g, '_'); if (!/\.(mp3|m4a|wav)$/i.test(n)) return json(res, 400, { error: 'Use mp3, m4a or wav. Name it like calm.mp3, upbeat.mp3, premium.mp3 or energetic.mp3.' });
      const ws = fs.createWriteStream(`${D}/music/${n}`); req.pipe(ws); return ws.on('finish', () => json(res, 200, { ok: 1 }));
    }
    if (m === 'POST' && p === '/api/jobs') {
      if (!key()) return json(res, 400, { error: 'AI key missing. Open Settings and paste your Anthropic API key first.' });
      const b = await body(req), id = crypto.randomUUID(), info = {};
      for (const k of ['name', 'price', 'benefit', 'description', 'audience', 'cta', 'brand']) info[k] = String(b[k] || '').slice(0, 300);
      db.prepare("insert into jobs values(?,?,?,?,?,?,?,?)").run(id, 'draft', 'Uploading...', null, JSON.stringify(info), null, null, Date.now());
      return json(res, 200, { id });
    }
    if ((x = p.match(/^\/api\/jobs\/([\w-]+)(?:\/(\w+))?$/))) {
      const id = x[1], act = x[2], j = db.prepare('select * from jobs where id=?').get(id);
      if (!j) return json(res, 404, { error: 'Job not found.' });
      if (m === 'GET' && !act) return json(res, 200, view(id));
      if (m === 'PUT' && act === 'upload') {
        const name = u.searchParams.get('name') || '', ext = path.extname(name).toLowerCase();
        if (!['.mp4', '.mov', '.m4v', '.webm'].includes(ext)) return json(res, 400, { error: `Unsupported format "${ext}". Use MP4 or MOV.` });
        const vid = crypto.randomUUID(), file = `${D}/up/${vid}${ext}`, ws = fs.createWriteStream(file); let n = 0, dead = false;
        req.on('data', (c) => { n += c.length; if (n > MAXMB * 1048576 && !dead) { dead = true; ws.destroy(); fs.unlink(file, () => {}); json(res, 413, { error: `File too large (max ${MAXMB} MB).` }); } });
        req.pipe(ws);
        return ws.on('finish', async () => {
          if (dead) return;
          try { const meta = await probe(file); db.prepare('insert into videos values(?,?,?,?,?)').run(vid, id, file, file, JSON.stringify(meta)); json(res, 200, { ok: 1, dur: meta.dur }); }
          catch { fs.unlink(file, () => {}); json(res, 400, { error: 'That file is not a readable video.' }); }
        });
      }
      if (m === 'POST' && (act === 'start' || act === 'retry')) {
        if (!db.prepare('select 1 from videos where job=?').get(id)) return json(res, 400, { error: 'Upload at least one video first.' });
        db.prepare("update jobs set status='queued',error=null,phase='Waiting in queue...' where id=?").run(id); pump(); return json(res, 200, { ok: 1 });
      }
      if (m === 'POST' && act === 'edit') {
        const b = await body(req), c = String(b.command || '').slice(0, 500).trim();
        if (!c) return json(res, 400, { error: 'Write an edit command.' }); if (!['done', 'failed'].includes(j.status)) return json(res, 409, { error: 'Still working.' });
        db.prepare("update jobs set status='queued',cmd=?,error=null,phase='Waiting in queue...' where id=?").run(c, id); pump(); return json(res, 200, { ok: 1 });
      }
    }
    json(res, 404, { error: 'Not found' });
  } catch (e) { console.error(e); json(res, 500, { error: 'Server error: ' + e.message }); }
});
export { server, pump };
if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  db.exec("update jobs set status='queued' where status='running'");
  server.listen(E.PORT || 3000, () => { console.log('AI Reels Studio on :' + (E.PORT || 3000)); pump(); });
}

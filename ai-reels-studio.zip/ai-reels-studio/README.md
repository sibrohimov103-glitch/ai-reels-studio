# AI Reels Studio
Zero npm dependencies. Needs Node 22.5+ and FFmpeg (the Dockerfile installs both).
Local: `npm start`, open http://localhost:3000, paste your key in Settings.
Online: push this folder to GitHub, then on render.com choose New > Blueprint and select the repo (render.yaml sets up a server with a persistent disk). Open the URL Render gives you, go to Settings, paste your Anthropic key and set a password.
Data (SQLite database, uploads, rendered MP4s, music) lives in DATA_DIR (/data online).
